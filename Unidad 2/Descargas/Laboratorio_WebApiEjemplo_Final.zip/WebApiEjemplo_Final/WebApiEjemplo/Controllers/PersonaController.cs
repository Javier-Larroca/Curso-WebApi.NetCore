﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApiEjemplo.Models;

namespace WebApiEjemplo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonaController : ControllerBase
    {
        private List<Persona> _personas = new List<Persona>();

        public PersonaController()
        {
            _personas.Add(new Persona() {Id = 1, Nombre = "Juan", Apellido = "Suarez" });
            _personas.Add(new Persona() {Id = 2, Nombre = "Jaime", Apellido = "Manto" });
            _personas.Add(new Persona() {Id = 3, Nombre = "Jennifer", Apellido = "Diaz" });
            _personas.Add(new Persona() {Id = 4, Nombre = "Vanesa", Apellido = "Dupres" });
        }

        [HttpGet]
        [Produces("application/xml")]   //Retorna objetos persona en formato XML
        public List<Persona> GetAll()
        {
            return _personas;
        }

        [HttpGet("{id}")]
        public ActionResult<Persona> GetPersonaPorId(int id)
        {
            var persona = _personas.FirstOrDefault(p => p.Id == id);

            if (persona == null)
            {
                return NotFound();
            }

            return persona;
        }
    }
}