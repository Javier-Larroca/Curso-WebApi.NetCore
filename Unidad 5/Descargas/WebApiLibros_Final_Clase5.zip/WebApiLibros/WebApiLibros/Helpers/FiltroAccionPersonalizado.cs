﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;

namespace WebApiLibros.Helpers
{
    public class FiltroAccionPersonalizado : IActionFilter
    {
        private readonly ILogger<FiltroAccionPersonalizado> logger;

        // Inyección de dependencias para inyectar un logger así logear información
        public FiltroAccionPersonalizado(ILogger<FiltroAccionPersonalizado> logger)
        {
            this.logger = logger;
        }
        public void OnActionExecuting(ActionExecutingContext context)
        {
            logger.LogError("OnActionExecuting");
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            logger.LogError("OnActionExecuted");
        }

    }
}

